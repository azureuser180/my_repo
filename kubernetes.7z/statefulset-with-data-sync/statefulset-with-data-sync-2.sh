#!/bin/bash

# Create configMap.yaml
cat <<EOF > configMap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: mongodb-config
  namespace: default
data:
  mongod.conf: |
    storage:
      dbPath: /data/db
    net:
      bindIp: 0.0.0.0
    replication:
      replSetName: "rs0"
EOF

# Create secret.yaml
read -p "Enter MongoDB root username: " mongo_username
read -s -p "Enter MongoDB root password: " mongo_password
echo
mongo_username_base64=$(echo -n $mongo_username | base64)
mongo_password_base64=$(echo -n $mongo_password | base64)

cat <<EOF > secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: mongodb-secret
  namespace: default
type: Opaque
data:
  mongo-root-username: $mongo_username_base64
  mongo-root-password: $mongo_password_base64
EOF

# Create persistentVolume.yaml
cat <<EOF > persistentVolume.yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: mongodb-pv0
spec:
  capacity:
    storage: 10Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: /mnt/data0
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: mongodb-pv1
spec:
  capacity:
    storage: 10Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: /mnt/data1
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: mongodb-pv2
spec:
  capacity:
    storage: 10Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: /mnt/data2
EOF

# Create persistentVolumeClaim.yaml
cat <<EOF > persistentVolumeClaim.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: mongodb-pvc
  namespace: default
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
EOF

# Create statefulset.yaml
cat <<EOF > statefulset.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: mongodb
  namespace: default
spec:
  serviceName: "mongodb"
  replicas: 3
  selector:
    matchLabels:
      app: mongodb
  template:
    metadata:
      labels:
        app: mongodb
    spec:
      containers:
      - name: mongodb
        image: mongo:4.4.6
        ports:
        - containerPort: 27017
          name: mongo
        volumeMounts:
        - name: mongo-data
          mountPath: /data/db
        - name: config-volume
          mountPath: /etc/mongo
        env:
        - name: MONGO_INITDB_ROOT_USERNAME
          valueFrom:
            secretKeyRef:
              name: mongodb-secret
              key: mongo-root-username
        - name: MONGO_INITDB_ROOT_PASSWORD
          valueFrom:
            secretKeyRef:
              name: mongodb-secret
              key: mongo-root-password
        command: [ "mongod", "--config", "/etc/mongo/mongod.conf" ]
      volumes:
      - name: config-volume
        configMap:
          name: mongodb-config
  volumeClaimTemplates:
  - metadata:
      name: mongo-data
    spec:
      accessModes: [ "ReadWriteOnce" ]
      resources:
        requests:
          storage: 10Gi
EOF

# Create service.yaml
cat <<EOF > service.yaml
apiVersion: v1
kind: Service
metadata:
  name: mongodb
  namespace: default
spec:
  ports:
  - port: 27017
    name: mongo
  clusterIP: None
  selector:
    app: mongodb
EOF

# Create initialization-script.yaml
cat <<EOF > initialization-script.yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: mongodb-init
  namespace: default
spec:
  template:
    spec:
      containers:
      - name: mongo-init
        image: mongo:4.4.6
        command: [ "mongo" ]
        args:
          - "--eval"
          - >
            rs.initiate({
              _id: "rs0",
              members: [
                { _id: 0, host: "mongodb-0.mongodb.default.svc.cluster.local:27017" },
                { _id: 1, host: "mongodb-1.mongodb.default.svc.cluster.local:27017" },
                { _id: 2, host: "mongodb-2.mongodb.default.svc.cluster.local:27017" }
              ]
            })
      restartPolicy: OnFailure
EOF

# Apply the configurations in the correct order
kubectl apply -f configMap.yaml
kubectl apply -f secret.yaml
kubectl apply -f persistentVolume.yaml
kubectl apply -f persistentVolumeClaim.yaml
kubectl apply -f service.yaml
kubectl apply -f statefulset.yaml
# kubectl apply -f initialization-script.yaml
